package com.example.inside_medhelp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
