class DoctorModel{
  String?Specification;
  String?activity;
  String?imageurl;
  DoctorModel(this.Specification,this.activity,this.imageurl);
}