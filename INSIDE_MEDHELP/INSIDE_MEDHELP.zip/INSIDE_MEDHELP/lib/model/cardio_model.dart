class CardioModel{
  String?Name;
  String?Hospital;
  String?imageurl;
  String?date;
  CardioModel(this.Name,this.Hospital,this.imageurl,this.date);
}